<h1 class="contract"> hi </h1>

Stub for hi action's ricardian contract